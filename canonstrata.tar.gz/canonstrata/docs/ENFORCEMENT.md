# Enforcement Rules

## AST Enforcement

### Boundary Violations

**Rule**: Layers can only import from allowed dependencies

**Detection**: Static AST analysis with `ts-morph`

**Examples**:

```typescript
// ❌ VIOLATION: src/lib importing from src/app
// File: src/lib/utils.ts
import { something } from '@/app/page';

// ✅ CORRECT
import { something } from '@/core/types';
```

### Purity Annotations

**Rule**: Functions in `src/lib/` must be pure or annotated

**Detection**: AST analysis for side effects

**Examples**:

```typescript
// ✅ CORRECT: Pure function
export function add(a: number, b: number): number {
  return a + b;
}

// ✅ CORRECT: Side effect annotated
/**
 * @sideEffect Writes to localStorage
 */
export function saveData(data: string): void {
  localStorage.setItem('data', data);
}

// ❌ VIOLATION: Side effect without annotation
export function saveData(data: string): void {
  localStorage.setItem('data', data);
}
```

## Design System Enforcement

### No Design Literals

**Rule**: No hardcoded colors, spacing, typography

**Detection**: Regex pattern matching in AST

**Examples**:

```typescript
// ❌ VIOLATION: Hardcoded color
const Button = styled.button`
  color: #0ea5e9;
  padding: 16px;
`;

// ✅ CORRECT: Using tokens
import tokens from '@/tokens';

const Button = styled.button`
  color: ${tokens.colors['primary-500']};
  padding: ${tokens.spacing['4']};
`;
```

### No Magic Motion

**Rule**: No hardcoded animation values

**Detection**: AST analysis of motion props

**Examples**:

```typescript
// ❌ VIOLATION: Hardcoded motion
<motion.div
  transition={{ duration: 300, ease: 'easeInOut' }}
/>

// ✅ CORRECT: Using motion tokens
<motion.div
  transition={{
    duration: motionTokens.duration.normal,
    ease: motionTokens.easing.smooth
  }}
/>
```

## Client/Server Boundaries

### Server-Only in Client

**Rule**: Client components cannot import server-only modules

**Detection**: AST analysis of imports in 'use client' files

**Blocked Imports**: `fs`, `path`, `crypto`, `child_process`, `os`

### Client-Only in Server

**Rule**: Server components cannot use React hooks

**Detection**: AST analysis for hook usage

**Blocked Hooks**: `useState`, `useEffect`, `useContext`, etc.

## Schema Synchronization

### Zod-TypeScript Sync

**Rule**: Every TypeScript type must have a corresponding Zod schema

**Detection**: Compare exports from `types.ts` and `schemas.ts`

**Example**:

```typescript
// src/core/types.ts
export interface User {
  id: string;
  email: string;
  name: string;
}

// src/core/schemas.ts (MUST exist)
export const UserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  name: z.string(),
});
```

## Bundle Budget

### Size Limits

**Rule**: Bundle sizes must stay within defined limits

**Enforcement**: `size-limit` integration

**Configuration**:

```json
{
  "name": "App Bundle",
  "limit": "200 KB"
}
```

**Action**: CI fails if exceeded

## Token Validation

### Token Structure

**Rule**: All token files must be valid JSON with correct structure

**Checks**:
- Valid JSON syntax
- Required token files exist
- No duplicate tokens
- Valid token references

### Token References

**Rule**: Token references must point to existing tokens

**Example**:

```json
{
  "primary": "{colors.blue-500}"  // ✅ Must exist in colors
}
```

## CI/CD Hard-Fail Gates

All enforcement rules cause CI pipeline failure:

1. **constitutional-enforcement** job
   - Type check
   - Lint
   - Format check

2. **ast-enforcement** job
   - AST boundary check
   - Import validation
   - Purity checks

3. **design-system-enforcement** job
   - Token validation
   - No design literals
   - No magic motion

4. **schema-synchronization** job
   - Zod sync check

5. **invariant-tests** job
   - Playwright invariant tests

6. **bundle-budget** job
   - Size limit checks

7. **security-audit** job
   - npm audit (high severity)

Any failure blocks merge and deployment.
