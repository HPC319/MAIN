# Architecture Guide

## Constitutional Layers

### Kernel Layer (Immutable Core)

**Location**: `src/core/`, `src/kernel/`

**Purpose**: Immutable contracts and core business logic

**Rules**:
- No external dependencies except type libraries
- All exports are `DeepReadonly`
- No side effects
- Pure functions only

**Contents**:
- Type definitions (`types.ts`)
- Interface contracts (`interfaces.ts`)
- Zod schemas (`schemas.ts`)
- Configuration (`config.ts`)

### Governed Layer (Controlled Zone)

**Location**: `src/lib/`, `src/components/`

**Purpose**: Reusable utilities and UI components

**Rules**:
- Can import from Kernel layer
- Must use design tokens (no hardcoded values)
- All functions must be pure or clearly annotated
- Components must be client/server boundary aware

**Contents**:
- Pure utility functions (`src/lib/utils/`)
- UI components (`src/components/ui/`)
- Hooks (`src/lib/hooks/`)

### Surface Layer (Application)

**Location**: `src/app/`

**Purpose**: User-facing application routes and pages

**Rules**:
- Can import from Kernel and Governed layers
- Cannot import from Isolation zone
- Must follow Next.js conventions
- Must use proper client/server directives

**Contents**:
- Pages and routes
- Layouts
- Route handlers

### Isolation Zone (Contractors)

**Location**: `src/contractors/`

**Purpose**: External integrations and third-party code

**Rules**:
- Can ONLY import contract surfaces from `src/core/`
- Cannot import from any other layer
- Must implement defined interfaces
- Complete isolation from application code

**Contents**:
- Third-party integrations
- External API clients
- Legacy code adapters

## Boundary Enforcement

### Static Analysis

All boundaries are enforced via AST analysis using `ts-morph`:

```typescript
// ❌ Violation: Surface importing from Isolation
// src/app/page.tsx
import { SomeContractor } from '@/contractors/some-contractor';

// ✅ Correct: Surface importing from Governed
// src/app/page.tsx
import { Button } from '@/components/ui/Button';
```

### Runtime Validation

Zod schemas provide runtime type safety:

```typescript
// Contract definition (src/core/schemas.ts)
export const UserSchema = z.object({
  id: UUIDSchema,
  email: EmailSchema,
  name: z.string().min(1).max(255),
});

// Usage
const user = UserSchema.parse(data); // Throws if invalid
```

## Design System Integration

### Token Architecture

All design values flow from token files:

```
design-system/tokens/*.tokens.json
    ↓
CSS Variables (globals.css)
    ↓
Tailwind Config
    ↓
Components
```

### Enforcement

- **AST Check**: Scans for hardcoded colors, spacing, typography
- **Hard-fail**: CI fails if literals are found
- **Auto-fix**: Suggest token replacements

## Motion System

### Motion Tokens

All animations use motion tokens:

```typescript
// ✅ Correct
import { motionTokens } from '@/tokens';

<motion.div
  transition={{
    duration: motionTokens.duration.normal,
    ease: motionTokens.easing.smooth
  }}
/>

// ❌ Wrong (will fail CI)
<motion.div
  transition={{
    duration: 300,
    ease: 'easeInOut'
  }}
/>
```

## Client/Server Boundaries

### Next.js Directives

Components must declare their execution context:

```typescript
// Client component
'use client';

export function InteractiveButton() {
  const [count, setCount] = useState(0);
  // ...
}

// Server component (default)
export async function UserList() {
  const users = await fetchUsers();
  // ...
}
```

### Enforcement

- Client components cannot import server-only modules
- Server components cannot use React hooks
- Violations fail CI pipeline

## Testing Strategy

### Invariant Tests

Playwright tests verify system-wide guarantees:

```typescript
test('all pages render without errors', async ({ page }) => {
  // Test implementation
});
```

### Unit Tests

Jest tests for pure functions:

```typescript
describe('formatDate', () => {
  it('formats dates correctly', () => {
    expect(formatDate('2024-01-01')).toBe('January 1, 2024');
  });
});
```

## Performance Budgets

Bundle sizes are enforced via `size-limit`:

```json
{
  "name": "App Bundle",
  "path": ".next/static/chunks/pages/_app.js",
  "limit": "200 KB"
}
```

Exceeding budgets fails the CI pipeline.
