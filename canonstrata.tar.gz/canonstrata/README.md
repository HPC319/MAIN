# CanonStrata

A **constitutionally governed** Next.js application with enforceable architectural boundaries, design system integration, and hard-fail CI/CD semantics.

## 🏛️ Constitutional Architecture

CanonStrata implements a layered architecture with strict boundary enforcement:

### Layer Structure

```
┌─────────────────────────────────────────┐
│         Surface Layer (src/app)         │  ← User-facing application
├─────────────────────────────────────────┤
│    Governed Layer (src/components)      │  ← UI components
│         (src/lib)                       │  ← Pure utilities
├─────────────────────────────────────────┤
│     Kernel Layer (src/kernel)           │  ← Business logic
│              (src/core)                 │  ← Core contracts
├─────────────────────────────────────────┤
│   Isolation Zone (src/contractors)      │  ← External integrations
└─────────────────────────────────────────┘
```

### Import Rules

- **src/core**: Cannot import anything (pure contracts)
- **src/kernel**: Can import from `src/core`
- **src/lib**: Can import from `src/core`, `src/kernel`
- **src/components**: Can import from `src/core`, `src/kernel`, `src/lib`
- **src/app**: Can import from all layers except `src/contractors`
- **src/contractors**: Can only import contract surfaces from `src/core`

## 🛡️ Enforcement Gates

All gates use **hard-fail semantics** - violations block CI/CD pipeline:

### AST Enforcement
```bash
npm run ast:check           # Full AST boundary enforcement
npm run boundary:check      # Layer boundary validation
npm run client-boundary:check # Client/Server boundary check
```

### Design System Enforcement
```bash
npm run tokens:validate     # Design token validation
npm run no-design-literals  # Prevent hardcoded design values
npm run motion:check        # Motion pattern validation
npm run no-magic-motion     # Prevent hardcoded motion values
```

### Schema Synchronization
```bash
npm run zod:sync           # Ensure Zod schemas match TypeScript types
```

### Bundle Budget
```bash
npm run bundle:check       # Enforce performance budgets
```

### Full Constitutional Enforcement
```bash
npm run constitutional:enforce  # Run all enforcement gates
```

## ✅ Invariant Tests

Playwright-based tests that guarantee system behavior:

```bash
npm run test:invariant     # Run all invariant tests
npm run test:unit          # Run unit tests
npm run test:all           # Run all tests
```

### Test Categories

- **Page Render Invariants**: Rendering guarantees across all pages
- **Form Submit Invariants**: Form behavior and validation
- **Existence Invariants**: Critical file/structure validation

## 🎨 Design System

All design values are managed through tokens in `design-system/tokens/`:

- `colors.tokens.json` - Color palette
- `typography.tokens.json` - Typography scale
- `spacing.tokens.json` - Spacing system
- `motion.tokens.json` - Animation patterns
- `shadows.tokens.json` - Shadow system
- `borders.tokens.json` - Border styles

### Token Usage

```typescript
// ✅ Correct - Using tokens
import tokens from '@/tokens';

const Button = styled.button`
  color: ${tokens.colors['primary-500']};
  padding: ${tokens.spacing['4']};
`;

// ❌ Wrong - Hardcoded values (will fail CI)
const Button = styled.button`
  color: #0ea5e9;
  padding: 1rem;
`;
```

## 🚀 Getting Started

### Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0

### Installation

```bash
# Install dependencies
npm ci

# Run development server
npm run dev

# Open http://localhost:3000
```

### Development Workflow

```bash
# 1. Start development
npm run dev

# 2. Make changes with enforcement
npm run validate           # Type-check + lint + constitutional enforcement

# 3. Run tests
npm run test:all

# 4. Build for production
npm run build
```

## 📦 Scripts Reference

### Development
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server

### Quality Checks
- `npm run type-check` - TypeScript type checking
- `npm run lint` - ESLint validation
- `npm run format:check` - Prettier formatting check
- `npm run validate` - Run all quality checks

### Constitutional Enforcement
- `npm run constitutional:enforce` - Run all enforcement gates
- `npm run constitutional:report` - Generate enforcement report

### Testing
- `npm run test:unit` - Unit tests with Jest
- `npm run test:invariant` - Invariant tests with Playwright
- `npm run test:coverage` - Generate coverage report

### Utilities
- `npm run size` - Check bundle sizes
- `npm run analyze` - Analyze bundle composition

## 🔄 CI/CD Pipeline

### Pull Request Checks

All PRs must pass:
1. ✅ Constitutional enforcement (AST, boundaries, design system)
2. ✅ Type checking
3. ✅ Linting
4. ✅ Unit tests
5. ✅ Invariant tests
6. ✅ Bundle budget
7. ✅ Security audit

### Deployment

Deployments to production require:
1. All PR checks passing
2. Post-deploy smoke tests
3. Performance validation (Lighthouse CI)

## 📖 Documentation

- [Architecture Guide](./docs/ARCHITECTURE.md)
- [Enforcement Rules](./docs/ENFORCEMENT.md)
- [Design System](./docs/DESIGN_SYSTEM.md)
- [Testing Strategy](./docs/TESTING.md)

## 🤝 Contributing

1. Create a feature branch
2. Make changes following constitutional rules
3. Run `npm run validate` to ensure compliance
4. Submit PR (all gates must pass)

## 📝 License

MIT License - See LICENSE file for details

## 🎯 Key Principles

### 1. Readability > Cleverness
Code should be immediately understandable without deep context.

### 2. No Dead Code
All code must be actively used or removed.

### 3. No Narrative Comments
Structure and naming should explain intent - comments only for "why", never "what".

### 4. Zero Duplication
Extract shared logic into pure, reusable functions.

### 5. Files Stand Alone
Each file should be understandable in isolation.

---

Built with constitutional governance and hard-fail semantics.
