/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: 'var(--primary-50)',
          500: 'var(--primary-500)',
          600: '#0284c7',
          700: 'var(--primary-700)',
        },
        secondary: {
          50: '#faf5ff',
          500: '#a855f7',
          600: '#9333ea',
        },
        neutral: {
          50: '#fafafa',
          200: '#e5e5e5',
          600: 'var(--neutral-600)',
          700: 'var(--neutral-700)',
          900: 'var(--neutral-900)',
        },
      },
    },
  },
  plugins: [],
};
