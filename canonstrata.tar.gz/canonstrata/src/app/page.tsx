import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-primary-50 via-secondary-50 to-primary-100">
      <div className="container mx-auto px-4 py-16">
        <header className="text-center mb-16">
          <h1 className="text-6xl font-bold text-neutral-900 mb-4">
            CanonStrata
          </h1>
          <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
            A constitutionally governed application architecture with enforceable boundaries,
            design system integration, and hard-fail semantics.
          </p>
        </header>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card title="🏛️ Constitutional Layers">
            <ul className="space-y-2 text-neutral-700">
              <li><strong>Kernel:</strong> Core types & contracts</li>
              <li><strong>Governed:</strong> Lib & components</li>
              <li><strong>Surface:</strong> Application layer</li>
              <li><strong>Isolation:</strong> Contractor zone</li>
            </ul>
          </Card>

          <Card title="🛡️ Enforcement Gates">
            <ul className="space-y-2 text-neutral-700">
              <li>AST boundary validation</li>
              <li>Design token enforcement</li>
              <li>Motion pattern validation</li>
              <li>Bundle budget checks</li>
            </ul>
          </Card>

          <Card title="✅ Invariant Tests">
            <ul className="space-y-2 text-neutral-700">
              <li>Page render guarantees</li>
              <li>Form behavior tests</li>
              <li>Existence validation</li>
              <li>Performance budgets</li>
            </ul>
          </Card>
        </div>

        <div className="text-center">
          <Button variant="primary" size="lg">
            Get Started
          </Button>
        </div>
      </div>
    </main>
  );
}
