'use client';

import { motion } from 'framer-motion';
import { ComponentProps } from '@/core/types';

interface CardProps extends ComponentProps {
  title: string;
  children: React.ReactNode;
}

export function Card({ title, children, className = '', testId, ...ariaProps }: CardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`
        bg-white rounded-xl shadow-lg p-6
        border border-neutral-200
        ${className}
      `}
      data-testid={testId}
      {...ariaProps}
    >
      <h3 className="text-xl font-bold text-neutral-900 mb-4">{title}</h3>
      <div>{children}</div>
    </motion.div>
  );
}
