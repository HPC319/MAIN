/**
 * Core Schemas - Zod Validation Schemas
 * Runtime validation contracts synchronized with TypeScript types
 */

import { z } from 'zod';

export const UUIDSchema = z.string().uuid();
export const ISODateTimeSchema = z.string().datetime();
export const EmailSchema = z.string().email();
export const URLSchema = z.string().url();

export const EntitySchema = z.object({
  id: UUIDSchema,
  createdAt: ISODateTimeSchema,
  updatedAt: ISODateTimeSchema
});

export const TimestampedSchema = z.object({
  createdAt: ISODateTimeSchema,
  updatedAt: ISODateTimeSchema
});

export const VersionedSchema = z.object({
  version: z.number().int().positive()
});

export const AuditableSchema = TimestampedSchema.extend({
  createdBy: UUIDSchema,
  updatedBy: UUIDSchema
});

export const PaginationParamsSchema = z.object({
  page: z.number().int().positive().optional(),
  pageSize: z.number().int().positive().max(100).optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).optional()
});

export const PaginatedSchema = <T extends z.ZodType>(itemSchema: T) =>
  z.object({
    items: z.array(itemSchema),
    total: z.number().int().nonnegative(),
    page: z.number().int().positive(),
    pageSize: z.number().int().positive(),
    hasNext: z.boolean(),
    hasPrevious: z.boolean()
  });

export const ValidationErrorSchema = z.object({
  field: z.string(),
  message: z.string(),
  code: z.string()
});

export const ValidationResultSchema = z.object({
  valid: z.boolean(),
  errors: z.array(ValidationErrorSchema)
});

export const EventTypeSchema = z.enum([
  'created',
  'updated',
  'deleted',
  'published',
  'archived'
]);

export const DomainEventSchema = EntitySchema.extend({
  type: EventTypeSchema,
  aggregateId: UUIDSchema,
  payload: z.any(),
  metadata: z.record(z.unknown())
});

export const CommandSchema = z.object({
  type: z.string(),
  payload: z.any(),
  metadata: z.record(z.unknown()).optional()
});

export const QuerySchema = z.object({
  type: z.string(),
  params: z.any(),
  metadata: z.record(z.unknown()).optional()
});

export const HTTPMethodSchema = z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);

export const APIRequestSchema = z.object({
  method: HTTPMethodSchema,
  path: z.string(),
  body: z.any().optional(),
  headers: z.record(z.string()).optional(),
  query: z.record(z.string()).optional()
});

export const APIResponseSchema = z.object({
  status: z.number().int(),
  data: z.any().optional(),
  error: z.object({
    message: z.string(),
    code: z.string(),
    details: z.unknown().optional()
  }).optional(),
  headers: z.record(z.string()).optional()
});

export const ConfigSchema = z.object({
  env: z.enum(['development', 'staging', 'production']),
  apiUrl: URLSchema,
  enableDebug: z.boolean(),
  features: z.record(z.boolean())
});

export const UserRoleSchema = z.enum(['admin', 'user', 'guest']);
export const UserStatusSchema = z.enum(['active', 'inactive', 'suspended']);

export const UserSchema = EntitySchema.extend({
  email: EmailSchema,
  name: z.string().min(1).max(255),
  role: UserRoleSchema,
  status: UserStatusSchema
});

export const SessionSchema = EntitySchema.extend({
  userId: UUIDSchema,
  token: z.string(),
  expiresAt: ISODateTimeSchema,
  metadata: z.record(z.unknown())
});

export const DesignTokenSchema = z.object({
  value: z.union([z.string(), z.number()]),
  type: z.enum(['color', 'spacing', 'typography', 'motion', 'shadow', 'border']),
  category: z.string().optional(),
  description: z.string().optional()
});

export const MotionTokenSchema = z.object({
  duration: z.number().positive(),
  easing: z.string(),
  delay: z.number().nonnegative().optional(),
  spring: z.object({
    stiffness: z.number().positive(),
    damping: z.number().positive(),
    mass: z.number().positive()
  }).optional()
});

export const ComponentPropsSchema = z.object({
  className: z.string().optional(),
  testId: z.string().optional(),
  'aria-label': z.string().optional(),
  'aria-describedby': z.string().optional()
});

export const FormStateSchema = <T extends z.ZodType>(valuesSchema: T) =>
  z.object({
    values: valuesSchema,
    errors: z.record(z.string()),
    touched: z.record(z.boolean()),
    isSubmitting: z.boolean(),
    isValid: z.boolean()
  });

export const AsyncStateSchema = <T extends z.ZodType>(dataSchema: T) =>
  z.object({
    data: dataSchema.nullable(),
    loading: z.boolean(),
    error: z.instanceof(Error).nullable()
  });

export const ContractorInterfaceSchema = z.object({
  id: UUIDSchema,
  name: z.string(),
  version: z.string(),
  execute: z.function(),
  validate: z.function()
}).readonly();

export const BoundaryViolationSchema = z.object({
  layer: z.string(),
  file: z.string(),
  line: z.number().int().positive(),
  violation: z.string(),
  severity: z.enum(['error', 'warning'])
});

export const EnforcementReportSchema = z.object({
  passed: z.boolean(),
  violations: z.array(BoundaryViolationSchema),
  filesScanned: z.number().int().nonnegative(),
  timestamp: ISODateTimeSchema
});

export function createResultSchema<T extends z.ZodType>(dataSchema: T) {
  return z.discriminatedUnion('success', [
    z.object({
      success: z.literal(true),
      data: dataSchema
    }),
    z.object({
      success: z.literal(false),
      error: z.instanceof(Error)
    })
  ]);
}
