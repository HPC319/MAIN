/**
 * Core Configuration - Type-Safe Application Config
 * Environment-aware configuration with validation
 */

import { z } from 'zod';
import { ConfigSchema } from './schemas';
import type { Config } from './types';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'staging', 'production']).default('development'),
  NEXT_PUBLIC_API_URL: z.string().url(),
  NEXT_PUBLIC_ENABLE_DEBUG: z.string().transform(val => val === 'true').default('false'),
  NEXT_PUBLIC_FEATURE_FLAG_NEW_UI: z.string().transform(val => val === 'true').default('false'),
  NEXT_PUBLIC_FEATURE_FLAG_ANALYTICS: z.string().transform(val => val === 'true').default('true'),
});

function validateEnv() {
  const parsed = envSchema.safeParse(process.env);

  if (!parsed.success) {
    console.error('❌ Invalid environment variables:', parsed.error.flatten().fieldErrors);
    throw new Error('Invalid environment variables');
  }

  return parsed.data;
}

const env = validateEnv();

export const config: Config = {
  env: env.NODE_ENV,
  apiUrl: env.NEXT_PUBLIC_API_URL,
  enableDebug: env.NEXT_PUBLIC_ENABLE_DEBUG,
  features: {
    newUI: env.NEXT_PUBLIC_FEATURE_FLAG_NEW_UI,
    analytics: env.NEXT_PUBLIC_FEATURE_FLAG_ANALYTICS,
  },
};

ConfigSchema.parse(config);

export const isDevelopment = config.env === 'development';
export const isStaging = config.env === 'staging';
export const isProduction = config.env === 'production';

export const API_BASE_URL = config.apiUrl;
export const DEBUG_MODE = config.enableDebug;

export const CACHE_TTL = {
  short: 60,
  medium: 300,
  long: 3600,
} as const;

export const PAGINATION_DEFAULTS = {
  pageSize: 20,
  maxPageSize: 100,
} as const;

export const VALIDATION_RULES = {
  maxNameLength: 255,
  maxDescriptionLength: 1000,
  minPasswordLength: 8,
  maxPasswordLength: 128,
} as const;

export const MOTION_PRESETS = {
  instant: 0,
  fast: 150,
  normal: 300,
  slow: 500,
} as const;

export function getFeatureFlag(name: keyof typeof config.features): boolean {
  return config.features[name] ?? false;
}

export function getConfig<K extends keyof Config>(key: K): Config[K] {
  return config[key];
}

if (DEBUG_MODE) {
  console.log('🔧 Configuration loaded:', config);
}
