/**
 * Core Interfaces - Constitutional Interface Contracts
 * Behavioral contracts for the entire system
 */

import type {
  UUID,
  ISODateTime,
  Result,
  AsyncResult,
  Entity,
  Paginated,
  PaginationParams,
  DomainEvent,
  Command,
  Query,
  APIRequest,
  APIResponse,
  ValidationResult,
  User,
  Session,
  FormState
} from './types';

export interface IRepository<T extends Entity> {
  findById(id: UUID): AsyncResult<T>;
  findAll(params?: PaginationParams): AsyncResult<Paginated<T>>;
  create(entity: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): AsyncResult<T>;
  update(id: UUID, entity: Partial<T>): AsyncResult<T>;
  delete(id: UUID): AsyncResult<void>;
}

export interface IEventBus {
  publish<T>(event: DomainEvent<T>): Promise<void>;
  subscribe<T>(eventType: string, handler: (event: DomainEvent<T>) => Promise<void>): void;
  unsubscribe(eventType: string, handler: Function): void;
}

export interface ICommandHandler<TCommand extends Command, TResult> {
  execute(command: TCommand): AsyncResult<TResult>;
  validate(command: TCommand): ValidationResult;
}

export interface IQueryHandler<TQuery extends Query, TResult> {
  execute(query: TQuery): AsyncResult<TResult>;
}

export interface IValidator<T> {
  validate(input: T): ValidationResult;
  validateAsync(input: T): Promise<ValidationResult>;
}

export interface ICache {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttl?: number): Promise<void>;
  delete(key: string): Promise<void>;
  clear(): Promise<void>;
  has(key: string): Promise<boolean>;
}

export interface ILogger {
  debug(message: string, context?: Record<string, unknown>): void;
  info(message: string, context?: Record<string, unknown>): void;
  warn(message: string, context?: Record<string, unknown>): void;
  error(message: string, error?: Error, context?: Record<string, unknown>): void;
}

export interface IAuthService {
  login(email: string, password: string): AsyncResult<Session>;
  logout(sessionId: UUID): AsyncResult<void>;
  getCurrentUser(): AsyncResult<User>;
  validateSession(token: string): AsyncResult<Session>;
  refreshSession(token: string): AsyncResult<Session>;
}

export interface IAPIClient {
  request<TResponse, TRequest = any>(
    request: APIRequest<TRequest>
  ): Promise<APIResponse<TResponse>>;
  get<TResponse>(path: string, query?: Record<string, string>): Promise<APIResponse<TResponse>>;
  post<TResponse, TRequest = any>(path: string, body: TRequest): Promise<APIResponse<TResponse>>;
  put<TResponse, TRequest = any>(path: string, body: TRequest): Promise<APIResponse<TResponse>>;
  patch<TResponse, TRequest = any>(path: string, body: Partial<TRequest>): Promise<APIResponse<TResponse>>;
  delete<TResponse>(path: string): Promise<APIResponse<TResponse>>;
}

export interface IStorageService {
  getItem<T>(key: string): T | null;
  setItem<T>(key: string, value: T): void;
  removeItem(key: string): void;
  clear(): void;
}

export interface INotificationService {
  success(message: string): void;
  error(message: string): void;
  warning(message: string): void;
  info(message: string): void;
}

export interface IFormHandler<T> {
  handleSubmit(values: T): AsyncResult<void>;
  handleChange(field: keyof T, value: any): void;
  handleBlur(field: keyof T): void;
  reset(): void;
  getState(): FormState<T>;
}

export interface ITokenProvider {
  getToken(path: string): any;
  validateToken(path: string): boolean;
  getAllTokens(): Record<string, any>;
}

export interface IMotionProvider {
  getMotion(name: string): any;
  validateMotion(config: any): boolean;
  getAllMotions(): Record<string, any>;
}

export interface IBoundaryEnforcer {
  checkBoundaries(filePath: string): AsyncResult<void>;
  validateImports(filePath: string): AsyncResult<ValidationResult>;
  reportViolations(): string[];
}

export interface IContractValidator {
  validateContract(contractId: UUID): AsyncResult<ValidationResult>;
  enforceContract(contractId: UUID): AsyncResult<void>;
}

export interface IDesignSystemProvider {
  getColors(): Record<string, string>;
  getTypography(): Record<string, any>;
  getSpacing(): Record<string, string>;
  getMotion(): Record<string, any>;
  validateUsage(filePath: string): ValidationResult;
}

export interface ITestRunner {
  runInvariants(): AsyncResult<void>;
  runUnit(): AsyncResult<void>;
  runIntegration(): AsyncResult<void>;
  generateReport(): string;
}

export interface IMetricsCollector {
  recordMetric(name: string, value: number, tags?: Record<string, string>): void;
  recordEvent(name: string, properties?: Record<string, unknown>): void;
  flush(): Promise<void>;
}

export interface IFeatureFlag {
  isEnabled(flagName: string): boolean;
  getAllFlags(): Record<string, boolean>;
}

export interface IErrorHandler {
  handleError(error: Error): void;
  reportError(error: Error, context?: Record<string, unknown>): Promise<void>;
}

export interface ISecurityService {
  sanitizeInput(input: string): string;
  validateCSRF(token: string): boolean;
  hashPassword(password: string): Promise<string>;
  comparePassword(password: string, hash: string): Promise<boolean>;
}

export interface IMiddleware<TContext> {
  execute(context: TContext, next: () => Promise<void>): Promise<void>;
}

export interface IPlugin {
  name: string;
  version: string;
  initialize(): Promise<void>;
  destroy(): Promise<void>;
}
