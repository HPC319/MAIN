/**
 * Core Types - Constitutional Type Definitions
 * Immutable type contracts for the entire system
 */

export type UUID = string;
export type ISODateTime = string;
export type Email = string;
export type URL = string;

export type Result<T, E = Error> = 
  | { success: true; data: T }
  | { success: false; error: E };

export type AsyncResult<T, E = Error> = Promise<Result<T, E>>;

export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;

export interface Entity {
  id: UUID;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}

export interface Timestamped {
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}

export interface Versioned {
  version: number;
}

export interface Auditable extends Timestamped {
  createdBy: UUID;
  updatedBy: UUID;
}

export type DeepReadonly<T> = {
  readonly [P in keyof T]: T[P] extends object ? DeepReadonly<T[P]> : T[P];
};

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasNext: boolean;
  hasPrevious: boolean;
}

export interface PaginationParams {
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface ValidationError {
  field: string;
  message: string;
  code: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

export type EventType = 
  | 'created'
  | 'updated'
  | 'deleted'
  | 'published'
  | 'archived';

export interface DomainEvent<T = any> extends Entity {
  type: EventType;
  aggregateId: UUID;
  payload: T;
  metadata: Record<string, unknown>;
}

export interface Command<T = any> {
  type: string;
  payload: T;
  metadata?: Record<string, unknown>;
}

export interface Query<T = any> {
  type: string;
  params: T;
  metadata?: Record<string, unknown>;
}

export type HTTPMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface APIRequest<T = any> {
  method: HTTPMethod;
  path: string;
  body?: T;
  headers?: Record<string, string>;
  query?: Record<string, string>;
}

export interface APIResponse<T = any> {
  status: number;
  data?: T;
  error?: {
    message: string;
    code: string;
    details?: unknown;
  };
  headers?: Record<string, string>;
}

export interface Config {
  env: 'development' | 'staging' | 'production';
  apiUrl: string;
  enableDebug: boolean;
  features: Record<string, boolean>;
}

export interface User extends Entity {
  email: Email;
  name: string;
  role: UserRole;
  status: UserStatus;
}

export type UserRole = 'admin' | 'user' | 'guest';
export type UserStatus = 'active' | 'inactive' | 'suspended';

export interface Session extends Entity {
  userId: UUID;
  token: string;
  expiresAt: ISODateTime;
  metadata: Record<string, unknown>;
}

export interface DesignToken {
  value: string | number;
  type: 'color' | 'spacing' | 'typography' | 'motion' | 'shadow' | 'border';
  category?: string;
  description?: string;
}

export interface MotionToken {
  duration: number;
  easing: string;
  delay?: number;
  spring?: {
    stiffness: number;
    damping: number;
    mass: number;
  };
}

export interface ComponentProps {
  className?: string;
  testId?: string;
  'aria-label'?: string;
  'aria-describedby'?: string;
}

export interface FormState<T> {
  values: T;
  errors: Record<keyof T, string>;
  touched: Record<keyof T, boolean>;
  isSubmitting: boolean;
  isValid: boolean;
}

export interface AsyncState<T> {
  data: Nullable<T>;
  loading: boolean;
  error: Nullable<Error>;
}

export type ContractorInterface = DeepReadonly<{
  id: UUID;
  name: string;
  version: string;
  execute: (input: unknown) => Promise<unknown>;
  validate: (input: unknown) => ValidationResult;
}>;

export interface BoundaryViolation {
  layer: string;
  file: string;
  line: number;
  violation: string;
  severity: 'error' | 'warning';
}

export interface EnforcementReport {
  passed: boolean;
  violations: BoundaryViolation[];
  filesScanned: number;
  timestamp: ISODateTime;
}
